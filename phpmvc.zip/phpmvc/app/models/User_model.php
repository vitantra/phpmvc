<?php
class User_Model
{
    private $nama = "Guru RPL";
    public function getUser()
    {
        return $this->nama;
    }
}
